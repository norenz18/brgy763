#
# TABLE STRUCTURE FOR: blotter
#

DROP TABLE IF EXISTS `blotter`;

CREATE TABLE `blotter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `caseNo` text NOT NULL,
  `complainant` varchar(255) NOT NULL,
  `compResident` varchar(255) NOT NULL,
  `dateOfFiling` date NOT NULL,
  `pic` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `textArea` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `blotter` (`id`, `caseNo`, `complainant`, `compResident`, `dateOfFiling`, `pic`, `status`, `textArea`) VALUES (1, '2021-01', 'test', 'test', '2021-04-02', 'test', 'Pending', 'Lorem ipsum keme keme keme 48 years na ang kasi nang shonga-shonga ano at bongga keme keme tamalis ng pamin balaj ganda lang bella dites buya at nang warla borta wasok bakit waz kasi guash Mike jutay shala bakit ma-kyonget biway cheapangga ano na ganda lang chuckie shonget buya chipipay mashumers nakakalurky sangkatuts keme keme emena gushung mashumers at bakit nang at makyonget at chuckie kasi jowa katagalugan kasi na sa ugmas nakakalurky tungril ang sa kemerloo ng sa otoko emena gushung at nang wrangler ng jowa dites chopopo warla ano ng shala mashumers at ang at bakit ganda lang jowabella keme keme planggana na makyonget shokot intonses sudems ugmas at bakit daki 48 years sangkatuts at nang krang-krang bigalou intonses waz shongaers bokot. Lorem ipsum keme keme keme 48');
INSERT INTO `blotter` (`id`, `caseNo`, `complainant`, `compResident`, `dateOfFiling`, `pic`, `status`, `textArea`) VALUES (2, '2021-02', 'testing', 'testing', '2021-04-04', 'testing', 'On-going', 'qweqweqeqeqwe qeqeqe');


#
# TABLE STRUCTURE FOR: certificate
#

DROP TABLE IF EXISTS `certificate`;

CREATE TABLE `certificate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(20) NOT NULL,
  `fullName` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `punongBrgy` varchar(255) NOT NULL,
  `businessName` varchar(255) NOT NULL,
  `businessType` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: officials
#

DROP TABLE IF EXISTS `officials`;

CREATE TABLE `officials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profImage` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `chairmanship` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `rank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4;

INSERT INTO `officials` (`id`, `profImage`, `firstname`, `lastname`, `middlename`, `chairmanship`, `role`, `rank`) VALUES (20, 'kagawad22.jpg', 'corazon', 'villanueva', 'c.', 'Committee on Peace & Order', 'Kagawad', 3);
INSERT INTO `officials` (`id`, `profImage`, `firstname`, `lastname`, `middlename`, `chairmanship`, `role`, `rank`) VALUES (21, 'kagawad3.jpg', 'Angelo Karlo', 'Clarino', 'S.', 'Committee on Health, Social Services & Sanitation', 'Kagawad', 4);
INSERT INTO `officials` (`id`, `profImage`, `firstname`, `lastname`, `middlename`, `chairmanship`, `role`, `rank`) VALUES (23, 'kagawad5.jpg', 'Joseph', 'malabanan', 'P.', 'Committee on Justice & Human Rights', 'Kagawad', 6);
INSERT INTO `officials` (`id`, `profImage`, `firstname`, `lastname`, `middlename`, `chairmanship`, `role`, `rank`) VALUES (24, 'kagawad6.jpg', 'Johannah', 'Ibrahim', 'A,', 'Committee on Public works & Infrastructure', 'Kagawad', 7);
INSERT INTO `officials` (`id`, `profImage`, `firstname`, `lastname`, `middlename`, `chairmanship`, `role`, `rank`) VALUES (25, 'kagawad7.jpg', 'Napoleon', 'Seneres', 'P.', 'Committee on Solid Waste Management', 'Kagawad', 8);
INSERT INTO `officials` (`id`, `profImage`, `firstname`, `lastname`, `middlename`, `chairmanship`, `role`, `rank`) VALUES (26, 'sk.jpg', 'Adrine', 'Ferrer', 'A.', 'Committee on Youth & Sport Development', 'Sk Chairman', 9);
INSERT INTO `officials` (`id`, `profImage`, `firstname`, `lastname`, `middlename`, `chairmanship`, `role`, `rank`) VALUES (27, 'secretary.jpg', 'Antonette', 'Vitero', 'A.', 'No Declared Chairmanship', 'Secretary', 10);
INSERT INTO `officials` (`id`, `profImage`, `firstname`, `lastname`, `middlename`, `chairmanship`, `role`, `rank`) VALUES (28, 'treasurer.jpg', 'Alejandro', 'Vitero', 'A.', 'No Declared Chairmanship', 'Treasurer', 11);
INSERT INTO `officials` (`id`, `profImage`, `firstname`, `lastname`, `middlename`, `chairmanship`, `role`, `rank`) VALUES (36, 'kagawad.jpg', 'ofelia', 'dalugdug', 'f.', 'Committee on Appropriations', 'Kagawad', 2);
INSERT INTO `officials` (`id`, `profImage`, `firstname`, `lastname`, `middlename`, `chairmanship`, `role`, `rank`) VALUES (37, 'kagawad4.jpg', 'James', 'Ariola', 'B.', 'Committee on Education, Cultural Affairs & Tourism', 'Kagawad', 5);
INSERT INTO `officials` (`id`, `profImage`, `firstname`, `lastname`, `middlename`, `chairmanship`, `role`, `rank`) VALUES (42, 'captain.jpg', 'edison \'\'sonny\'\'', 'jimeno', 'm.', 'Presiding Officer', 'Punong Barangay', 1);


#
# TABLE STRUCTURE FOR: posts
#

DROP TABLE IF EXISTS `posts`;

CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `posts` (`id`, `title`, `slug`, `body`, `created_at`) VALUES (1, 'liquor ban', 'liquor-ban', 'lumipad ang aming team papunta sa lugar na kami lang ang may alam. hulaan nyo kung saan, secret walang clue habang kami ay nag kakantahan ng hayaan mo sila.', '2021-04-02 16:15:21');


#
# TABLE STRUCTURE FOR: tbl_name
#

DROP TABLE IF EXISTS `tbl_name`;

CREATE TABLE `tbl_name` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profImage` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `mi` text NOT NULL,
  `birthdate` varchar(255) NOT NULL,
  `contact` bigint(15) NOT NULL,
  `age` int(3) NOT NULL,
  `seniorCitizen` text NOT NULL,
  `voterStatus` varchar(3) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `civilStatus` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `pwd` text NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `registerDate` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` (`id`, `name`, `email`, `username`, `password`, `registerDate`) VALUES (1, 'brgy763manila', 'brgy763@gmail.com', 'brgy763manila', '21232f297a57a5a743894a0e4a801fc3', '2021-04-02 16:04:30');


